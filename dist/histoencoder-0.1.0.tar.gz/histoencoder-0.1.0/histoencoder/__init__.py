"""HistoEncoder: Foundation model for digital pathology."""

from . import functional
