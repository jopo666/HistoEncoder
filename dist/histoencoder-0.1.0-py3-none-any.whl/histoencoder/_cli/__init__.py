"""CLI interface for HistoEncoder."""
from ._run import run
